package com.test.sampleconstrintsexample;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class QuizResultActivity extends AppCompatActivity
{
    TextView txtScore, txtResult, txtGreetings,edt;
    Button btnplagain;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz_result);

        intiActionBar();

        txtScore = (TextView)findViewById(R.id.txtScore);
        txtResult = (TextView)findViewById(R.id.txtResult);
        txtGreetings = (TextView)findViewById(R.id.txtGreetings);
        edt = (TextView)findViewById(R.id.editText);
        btnplagain = (Button)findViewById(R.id.playagainbtn);
        int score = getIntent().getExtras().getInt("result",0);
        txtScore.setText("Score : " + score);
        blinkText();
        if(score <5)
        {
            txtScore.setTextColor(Color.RED);
            txtResult.setText("Fail");
            txtGreetings.setText("Bad Luck!!!");
        }
       else
        {
            txtScore.setTextColor(Color.GREEN);
            txtResult.setText("Pass");
            txtGreetings.setText("Congratulation!!!");
        }


        SharedPreferences sharedPreferences=getPreferences(MODE_PRIVATE);
        int highscore = sharedPreferences.getInt("highscore",0);
        if(highscore>=score) {
            edt.setText("Highest Score : "+highscore);
          //  Toast.makeText(this,"High Score : " + highscore,Toast.LENGTH_LONG).show();
        }
       else {
           edt.setText("New Score : "+score);
            SharedPreferences.Editor editor=sharedPreferences.edit();
            editor.putInt("highscore",score);
            editor.commit();
        }
btnplagain.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        startActivity(new Intent(QuizResultActivity.this, QuizDeskBoardActivity.class));
    }
});

    }

    private void intiActionBar()
    {
        ActionBar actionBar = getSupportActionBar();
        actionBar.setLogo(R.drawable.trophyyy);
        actionBar.setDisplayUseLogoEnabled(true);
        actionBar.setDisplayShowHomeEnabled(true);
    }

    private void blinkText(){
        AlphaAnimation anim = new AlphaAnimation(0.0f, 1.0f);
        anim.setDuration(50); //You can manage the blinking time with this parameter
        anim.setStartOffset(20);
        anim.setRepeatMode(Animation.REVERSE);
        txtGreetings.setAnimation(anim);
    }
}
