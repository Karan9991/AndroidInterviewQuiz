# Quiz

Simple QUIZ application to demonstrate some andoid features
  - Timer
  - Splash Screen
  - Login Form
  - Action Menu
  - Progress Dialog
  - Pass Result to next Activity
  - POJO for Data model class
  - Usage of ArrayList
  - Text Blink - Drawable 
  - Layout designs
  - ActionBar options
